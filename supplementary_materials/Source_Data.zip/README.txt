Source Data for Bounding the rate loss of individual wireless uplink schedules.
Six main figures, eight supplementary figures and sixteen supplementary tables each have one annotated UTF-8 text file containing labelled CSV blocks. Source filenames, denominators and timing cohorts are retained. Scientific explanations and aggregation rules are in the corresponding legends and Supplementary Notes.
